<template>
  <div class="search">
    123搜索
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';

onMounted(() => {

})
</script>

<style lang='scss' scoped>
// @import url(./index.scss);
</style>