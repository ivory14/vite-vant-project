<template>
  <div class="setting">
    123设置
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';

onMounted(() => {

})
</script>

<style lang='scss' scoped>
// @import url(./index.scss);
</style>