<template>
  <div class="friends">
    123朋友
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';

onMounted(() => {

})
</script>

<style lang='scss' scoped>
// @import url(./index.scss);
</style>